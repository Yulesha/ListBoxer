/**
 * Created by user on 27.07.17.
 */
public class MainClass {

    public static void main(String[] args) {
        ListBoxer app = new ListBoxer();
        app.setVisible(true);
    }
}
